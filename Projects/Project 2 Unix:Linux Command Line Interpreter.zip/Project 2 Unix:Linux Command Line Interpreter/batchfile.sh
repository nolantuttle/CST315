#!/bin/bash
clear
echo "This is the first line of the batch file!"
echo "This is the second line!"
echo "This program runs using parent and child processes."
echo "For all commands given separated by a semicolon (;)"
echo "they will be executed concurrently."
echo ""
