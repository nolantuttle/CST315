Nolan Tuttle	
1/19/25
Professor Citro
Project 1: Familiarity with UNIX/Linux

Github Repository Link: https://github.com/nolantuttle/CST315.git
