Hi, my name is Nolan Tuttle, this is my git repository for CST315.
I'm studying Software Engineering with the hopes of becoming a full stack or 
backend Software Engineer. Java is my favorite programming language but I'm 
familiar with a handful of others like C++ and C#. 
